const core = require('@actions/core');
const axios = require('axios');
const ORCHESTRATION_TASK_PENDING_STATE = 'building';

(async function main() {
  const headers = { 'Content-Type': 'application/json' }

  const env = JSON.parse(core.getInput('context-env'));
  const github = JSON.parse(core.getInput('context-github'));
  let orchestrationTaskUrl = github.workflow.trim().replace(" ", "+"); // remove spaces
  let OTURLFULL = `${github.event.repository.html_url}/actions/?query=workflow:"${orchestrationTaskUrl}"`; 
  const orchestrationTaskUrlEncoded = encodeURIComponent(OTURLFULL);

  const sncNotifyURL = `https://${env.DEVOPS_INTEGRATION_USER_NAME}:${env.DEVOPS_INTEGRATION_USER_PASS}@${env.INSTANCE_NAME}.service-now.com/api/sn_devops/v1/devops/tool/orchestration?toolId=${env.TOOL_ID}`
  const sncChangeControLURL = `https://${env.DEVOPS_INTEGRATION_USER_NAME}:${env.DEVOPS_INTEGRATION_USER_PASS}@${env.INSTANCE_NAME}.service-now.com/api/sn_devops/devops/orchestration/changeControl?toolId=${env.TOOL_ID}&orchestrationTaskURL=${orchestrationTaskUrlEncoded}`
  const gitHubJobContextURL = `${github.api_url}/repos/${github.repository}/actions/runs/${github.run_id}`;
  const gitHubJobContextHeaders = { 'Authorization': `bearer ${github.token}` }

  let callback = { 'url': '' };

  let jobPayload;

  // get job payload
  try {
    jobPayload = await axios.get(gitHubJobContextURL, {
      headers: gitHubJobContextHeaders
    });
  } catch (e) {
    core.setFailed('Failed getting workflow job context ' + e);
    return;
  }

  let job = jobPayload.data;

  const jobResult = job.conclusion || ORCHESTRATION_TASK_PENDING_STATE;

  core.debug('checking change control ' + sncChangeControLURL)

  // determine if we're using change control
  let sncChangeControlCheck;
  try {
    sncChangeControlCheck = await axios.get(sncChangeControLURL);
  } catch (e) {
    core.setFailed('Failed checking snc change control api ' + e);
    return;
  }

  let changeControl = sncChangeControlCheck.data.result.changeControl;

  // if we're using change control create an issue.
  if (changeControl) {
    let issueURL = `${github.api_url}/repos/${github.repository}/issues`
    core.info('Change control is enabled - creating GitHub Issue')
    core.info("ISSUE URL " + issueURL);

    const issueData = {
      title: `DevOps orchestrationTask:${github.workflow}#${github.job}, action:build_test, build number:${github.run_number}` 
    }

    const issueConfig = {
      headers: {
        'Authorization': `bearer ${github.token}`, 
        'Accept': 'application/vnd.github.v3+json'  
      }
    };

    let issuePayload;
    try {
      issuePayload = await axios.post(issueURL, issueData, issueConfig);
    } catch (e) {
      core.setFailed('failed creating issue ' + e);
      return;
    }

    callback.url = issuePayload.data.url
  } else {
    core.info('Change control is not enabled for job - skipping issue creation');
  }

  core.debug('moving on to post notification ');

  let data = `{
    "toolid": "${env.TOOL_ID}",
    "buildNumber": "${github.run_number}",
    "nativeId": "${github.run_id}",
    "name": "${github.workflow}",
    "id": "${github.run_id}",
    "url": "${github.event.repository.html_url}/actions/runs/${github.run_id}",
    "isMultiBranch": "false",
    "orchestrationTaskUrl": "${github.event.repository.html_url}/actions/runs/${github.run_id}", 
    "orchestrationTaskName": "${github.workflow}#${github.job}", 
    "orchestrationTask": {
        "toolId" : "${env.TOOL_ID}", 
        "orchestrationTaskURL": "${github.event.repository.html_url}/actions/?query=workflow:\\"${orchestrationTaskUrl}\\"",
        "orchestrationTaskName": "${github.workflow}#${github.job}"
    },
    "startDateTime": "${job.created_at}",
    "result": "${jobResult}",
    "callback": {
      "toolId": "${env.TOOL_ID}",
      "callbackURL": "${callback.url}",
      "orchestrationTaskURL": "${github.event.repository.html_url}/actions/?query=workflow:\\"${orchestrationTaskUrl}\\"",
      "orchestrationTaskName":"${github.workflow}#${github.job}",
      "taskExecutionURL": "${github.event.repository.html_url}/actions/runs/${github.run_id}"
    }
}`;

  // send notification payload

  let notificationPayload;
  try {
    const notificationConfig = {
      headers: headers
    }
    notificationPayload = await axios.post(sncNotifyURL, data, notificationConfig);
  } catch (e) {
    core.setFailed('failed to send notification payload ' + e + sncNotifyURL + data);
  }
})();
